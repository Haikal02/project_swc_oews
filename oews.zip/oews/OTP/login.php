<?php
session_start();
include("dbconnect.php");
include("logging.php"); // Include the Logger class

$logger = new Logger('security.log'); // Initialize the logger

$email = $_SESSION['email'];
$otp = $_POST['user_otp'];

$logger->logSecurityEvent('OTP Verification Attempt', ['email' => $email, 'otp' => $otp]);

$sql = "Select * from users_otp where user_email='$email' and user_otp='$otp'";
$rs = mysqli_query($con, $sql) or die(mysqli_error($con));

if (mysqli_num_rows($rs) > 0) {
    $logger->logSecurityEvent('Successful OTP Verification', ['email' => $email, 'otp' => $otp]);
    $sql = "update users_otp set user_otp='' where user_email='$email'";
    $rs = mysqli_query($con, $sql) or die(mysqli_error($con));
    header('location: http://localhost/oews');
} else {
    $logger->logSecurityEvent('Failed OTP Verification', ['email' => $email, 'otp' => $otp, 'reason' => 'Invalid OTP']);
    header("location:index.php?msg=OTP is Invalid Plz try Again!!");
}
?>