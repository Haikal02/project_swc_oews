<?php
global $con;
$con=mysqli_connect("localhost","root","", "oews_db")  or die(mysqli_error($con));
$db=mysqli_select_db($con,"oews_db") or die(mysqli_error($con));
?>